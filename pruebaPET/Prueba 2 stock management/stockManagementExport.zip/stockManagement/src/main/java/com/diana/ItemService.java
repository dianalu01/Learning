package com.diana;

import java.math.BigInteger;
import java.util.List;

import com.diana.ItemModel;
/*Interfaz de Servicio de Item*/
public interface ItemService {
	/*Llama a la clase repositorio getAll*/
	List<ItemModel> getAll();
	/*Llama a la clase repositorio update*/
	boolean update(String id,String name,String description,BigInteger amount);
	/*Llama a la clase repositorio add */
	boolean add(ItemModel item);
	/*Llama a la clase repositorio delete*/
	boolean delete(String id);
}
