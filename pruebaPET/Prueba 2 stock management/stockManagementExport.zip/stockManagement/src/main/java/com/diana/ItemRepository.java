package com.diana;
/*Interfaz de repositorio para item*/
import java.math.BigInteger;
import java.util.List;

import com.diana.ItemModel;
public interface ItemRepository {
	/*Obtiene todos los items*/
	List<ItemModel> getAll();
	/*Modifica un item*/
	boolean update(String id,String name,String description,BigInteger amount);
	/*Inserta un item*/
	boolean add(ItemModel item);
	/*Elimina un item*/
	boolean delete(String id);
	/*verifica si el item existe segun su id*/
	boolean exist(String id);
}
