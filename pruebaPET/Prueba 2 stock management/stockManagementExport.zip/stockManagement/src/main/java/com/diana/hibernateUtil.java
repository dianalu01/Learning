package com.diana;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
 /*Clase utilizada para la creacion de la base de datos con la configulacion especificada en hibernate.cfg */
public class hibernateUtil {
	 
	private SessionFactory sessionFactory;
	private static hibernateUtil myHibernateConfigurator;
	/*Patron Singleton para la creacion de la sesion*/
	private hibernateUtil(){
		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	/*Devuelve la configuracion de hibernate*/
	public static hibernateUtil getHibernateConfigurator(){
		if(myHibernateConfigurator==null){
			myHibernateConfigurator= new hibernateUtil();
		}
		return myHibernateConfigurator;
	}
	/*Devuelve la session creada*/
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	/*Cierra la sesion*/
    public void shutdown() {
        getSessionFactory().close();
    }
}

