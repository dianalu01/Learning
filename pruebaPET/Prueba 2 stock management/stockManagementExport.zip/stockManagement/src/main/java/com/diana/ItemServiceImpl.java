package com.diana;

import java.math.BigInteger;
import java.util.List;

import com.diana.ItemModel;
import com.diana.ItemRepository;
import com.diana.ItemService;
import com.diana.ItemRepositoryImpl;
/*Implementador de Servicio de Item*/
public class ItemServiceImpl implements ItemService {
	
	private ItemRepository itemRepository = new ItemRepositoryImpl();
	
	/*Llama a la clase repositorio getAll*/
	@Override
	public List<ItemModel> getAll() {
		List<ItemModel> preferences=itemRepository.getAll();
		return preferences;

	}

	/*Llama a la clase repositorio update*/
	@Override
	public boolean update(String id, String name, String description, BigInteger amount) {
		boolean result=false;
		result=itemRepository.update(id, name, description, amount);
		return result;
	}

	/*Llama a la clase repositorio add */
	@Override
	public boolean add(ItemModel item) {
		boolean result=false;
		result=itemRepository.add(item);
		return result;
	}

	/*Llama a la clase repositorio delete*/
	@Override
	public boolean delete(String id) {
		boolean result=false;
		result=itemRepository.delete(id);
		return result;
	}

}
